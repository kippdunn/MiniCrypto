Password is a number 1-1000
